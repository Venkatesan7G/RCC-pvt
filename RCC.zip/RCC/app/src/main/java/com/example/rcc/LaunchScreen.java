package com.example.rcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class LaunchScreen extends AppCompatActivity {

    RadioButton radioButton;
    RadioGroup radioGroup;
    EditText empName,empNumber;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try
        {
            this.getSupportActionBar().hide();
        }
        catch (NullPointerException e){}
        setContentView(R.layout.launch_screen);
        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);
        empName=findViewById(R.id.empName);
        empNumber=findViewById(R.id.empNumber);
        Button btnlogin = findViewById(R.id.btnlogin);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logIn();
            }
        });
    }

    public void logIn(){
        int selectedId = radioGroup.getCheckedRadioButtonId();
        radioButton = (RadioButton) findViewById(selectedId);
        String name=empName.getText().toString().trim();
        String number=empNumber.getText().toString();
        String shop = "";
        if (TextUtils.isEmpty(name)){
            empName.setError("Please Enter Name");
            empName.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(number)){
            empNumber.setError("Please Enter EMP Number");
            empNumber.requestFocus();
            return;
        }
        if(selectedId==-1){
            Toast.makeText(LaunchScreen.this,"Please Select any one shop...", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            Toast.makeText(LaunchScreen.this,radioButton.getText().toString().trim(), Toast.LENGTH_SHORT).show();
            shop = radioButton.getText().toString().trim();
        }

        Intent intent=new Intent(LaunchScreen.this,MainActivity.class);
        intent.putExtra("empName",name);
        intent.putExtra("empNumber",number);
        intent.putExtra("shop",shop);
        startActivity(intent);

    }
}