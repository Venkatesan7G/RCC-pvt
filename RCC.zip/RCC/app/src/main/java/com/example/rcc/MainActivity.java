package com.example.rcc;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    TextView ename, empNo, category, txtLine, txtEqipName, txtCheckDetails;
    RadioButton opA, opB, opC;
    RadioGroup optionsGroup;
    Button prevButton;
    int score, ans, nextC, flag;
    boolean submit;
    ArrayList<Integer> Answers;
    private File filePath = new File(Environment.getExternalStorageDirectory() + "/Demo.xls");
    String empName, empNumber, shop;
    String line[];
    String equipmentName[];
    String checkDetails[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            this.getSupportActionBar().hide();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE}, PackageManager.PERMISSION_GRANTED);

        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        empName = intent.getStringExtra("empName");
        empNumber = intent.getStringExtra("empNumber");
        shop = intent.getStringExtra("shop");

        if(shop.equals("SHOP A1")){

             line = new String[]{
                     "TRIM","DOOR ","DOOR ","DOOR ","DOOR ",
                     "DOOR ","DOOR ","DOOR ","MAIN ","SEAT SUB",
                     "CHASSIS","CHASSIS","CHASSIS","CHASSIS","CHASSIS",
                     "CHASSIS","CHASSIS","CHASSIS","CHASSIS","CHASSIS",
                     "CHASSIS","CHASSIS","CHASSIS","CHASSIS","CHASSIS",
                     "ENGINE SUB","ENGINE SUB","ENGINE SUB","CHASSIS","CHASSIS",
                     "CHASSIS","CHASSIS","CHASSIS","CHASSIS","CHASSIS",
                     "ENGINE SUB","ENGINE SUB","ENGINE SUB","ENGINE SUB","ENGINE SUB",
                     "ENGINE SUB","ENGINE SUB","ENGINE SUB","ENGINE SUB","ENGINE SUB",
                     "ENGINE SUB","CHASSIS","CHASSIS","CHASSIS","CHASSIS",
                     "CHASSIS","CHASSIS","FILLING","FILLING","FILLING",
                     "FILLING","FILLING","FILLING","FILLING","FILLING",
                     "FILLING","FILLING","FILLING","FILLING","FILLING",
                     "FILLING","FILLING","FILLING","FILLING","FILLING",
                     "FILLING","TYRE SUB","TYRE SUB","TYRE SUB","TYRE SUB",
                     "TYRE SUB","DG SUB","DG SUB","DG SUB","DG SUB",
                     "DG SUB","DG SUB","NO","DG SUB","DG SUB",
                     "DG SUB","DG SUB","FINAL","FINAL","FINAL",
                     "FINAL","FINAL","FINAL","FINAL","FINAL",
                     "FINAL","FINAL","FINAL","FINAL","TEST LINE",
                     "TEST LINE","TEST LINE","TEST LINE","TEST LINE","TEST LINE",
                     "TEST LINE","TEST LINE","TEST LINE","TEST LINE","TEST LINE",
                     "TEST LINE","TEST LINE","TEST LINE","TEST LINE","TEST LINE",
                     "TEST LINE","TEST LINE","TEST LINE","TEST LINE","TEST LINE",
                     "TEST LINE","TEST LINE","TEST LINE","TEST LINE","TEST LINE",
                     "TEST LINE","TEST LINE","TEST LINE","TYRE SUB","TYRE SUB",
                     "TYRE SUB","TYRE SUB","TYRE SUB","TYRE SUB","TYRE SUB",
                     "TYRE SUB","TYRE SUB","TYRE SUB","TYRE SUB","TYRE SUB",
                     "TYRE SUB","TYRE SUB","TYRE SUB","TYRE SUB","TYRE SUB",
                     "TYRE SUB","TYRE SUB","TYRE SUB","TYRE SUB","TYRE SUB"
             };

             equipmentName = new String[]{
                     "WIRING FEED CONVEYOR","DOOR REMOVE", "DOOR REMOVE", "DOOR REMOVE JIGS", "DOOR SUB CONVEYOR",
                     "DOOR SUB CONVEYOR", "DOOR SUB CONVEYOR", "DOOR ECOS", "MAIN CONVEYOR", "SEAT TRAVERSER",
                     "CRASHPAD CONVEYOR", "CRASHPAD CONVEYOR", "CRASHPAD CONVEYOR", "CRASHPAD CONVEYOR", "CRASHPAD LOADER",
                     "FUEL TANK TROLLEY", "FUEL TANK CONVEYOR", "REAR AXLE MODULE CONVEYOR", "REAR AXLE MODULE CONVEYOR", "REAR  DECKING",
                     "REAR  DECKING", "REAR  DECKING", "REAR  DECKING", "REAR  DECKING", "REAR  DECKING",
                     "FRONT  MODULE CONVEYOR", "FRONT  MODULE CONVEYOR", "FRONT  MODULE CONVEYOR", "ENGINE  DECKING", "ENGINE  DECKING",
                     "ENGINE  DECKING", "ENGINE  DECKING", "ENGINE  DECKING", "ENGINE  DECKING", "ENGINE  DECKING",
                     "ENGINE SUB CONVEYOR", "CL01 LIFTER  & CONVEYOR", "CL01 LIFTER  & CONVEYOR", "ENGINE SUB LINE CONVEYOR", "ENGINE SUB LINE",
                     "ENGINE SUB LINE", "ENGINE SUB LINE", "ENGINE SUB LINE", "BELT TENSIONER", "ATM OIL FILLING M/C",
                     "ENGINE HOIST", "TORQUE TROLLEY", "TORQUE TROLLEY", "TORQUE TROLLEY", "FEM CONVEYOR",
                     "FEM LOADER", "FINAL ASSIST CONVEYOR", "BRAKE OIL FILLING M/C RH", "BRAKE OIL FILLING M/C RH", "BRAKE OIL FILLING M/C RH",
                     "BRAKE OIL FILLING M/C LH", "BRAKE OIL FILLING M/C LH", "COOLANT  M/C RH", "COOLANT  M/C RH", "COOLANT  M/C LH",
                     "COOLANT  M/C LH", "W/WASHER FILLING  M/C", "W/WASHER FILLING  M/C", "W/WASHER FILLING  M/C", "A/C CHARGER BOOSTER",
                     "A/C CHARGER 1", "A/C CHARGER 1", "A/C CHARGER 1", "A/C CHARGER 2", "A/C CHARGER 2",
                     "A/C CHARGER 2", "SPARE TYRE LOADER", "S3 TYRE", "S3 TYRE", "S3 TYRE",
                     "S3 TYRE NUT RUNNERS", "DG FRONT PRIMER ROBOT", "DG FRONT SEALER", "DG FRONT SEALER", "DG REAR PRIMER",
                     "DG REAR PRIMER", "DG REAR  SEALER", "DG VISION SYSTEM", "DG SUB  LINE", "DG SUB  LINE",
                     "DG SUB  LINE", "DG FRONT LOADER", "LASER M/C 1", "LASER M/C 2", "SEAT SUB CONVEYOR",
                     "SEAT SUB CONVEYOR", "SEAT SUB CONVEYOR", "SEAT SUB CONVEYOR", "SEAT LOADERS", "DOOR MOUNT LOADER",
                     "DOOR MOUNT CONVEYOR", "FUEL FILLING M/C", "DIESEL AIR BLEEDING", "FINAL CONVEYOR", "WHEEL ALIGNMENT M/C 1",
                     "WHEEL ALIGNMENT M/C 1", "WHEEL ALIGNMENT M/C 2", "WHEEL ALIGNMENT M/C 2", "WHEEL ALIGNMENT M/C 3", "WHEEL ALIGNMENT M/C 3",
                     "ERREOR ERASER M/C 1", "ERREOR ERASER M/C 2", "ERREOR ERASER M/C 3", "ROLL BRAKE TEST M/C 1", "ROLL BRAKE TEST M/C 1",
                     "ROLL BRAKE TEST M/C 1", "ROLL BRAKE TEST M/C 2", "ROLL BRAKE TEST M/C 2", "ROLL BRAKE TEST M/C 2", "ROLL BRAKE TEST M/C 3",
                     "ROLL BRAKE TEST M/C 3", "ROLL BRAKE TEST M/C 3", "SHOWER TEST BOOTH #1", "SHOWER TEST BOOTH #1", "SHOWER TEST BOOTH #1",
                     "SHOWER TEST BOOTH #2", "SHOWER TEST BOOTH #2", "SHOWER TEST BOOTH #2", "SHOWER TEST CONVEYOR # 1", "SHOWER TEST CONVEYOR # 2",
                     "CS CONVEYOR # 1", "CS CONVEYOR # 2", "PAINT TOUCHUP BOOTH", "TYRE STORAGE CONVEYORS", "TYRE STORAGE CONVEYORS",
                     "TYRE STORAGE CONVEYORS", "TYRE STORAGE CONVEYORS", "WHEEL VISION SYSTEM", "TYRE MOUNTING M/C #1", "TYRE MOUNTING M/C #1",
                     "TYRE MOUNTING M/C #1", "TYRE MOUNTING M/C #2",  "TYRE MOUNTING M/C #2", "VALVE INSERTOR", "TPMS ID READER",
                     "TYRE LOAD CONVEYOR", "TYRE LOAD CONVEYOR", "AUDIT BALANCING M/C", "AUDIT BALANCING M/C", "HAMCO WHEEL BALANCING M/C",
                     "HAMCO WHEEL BALANCING M/C", "TYRE DELIVERY CONVEYOR", "TYRE DELIVERY CONVEYOR", "S3 TYRE OLD CONVEYOR", "S3 TYRE OLD CONVEYOR",
             };

             checkDetails = new String[]{
                     "ONE AUTO CYCLE CHECK", "ONE AUTO CYCLE CHECK", "CHECK REMOTE PC & BOTY S1 & MODULE PLC PROGRAM  ONLINE", "CHECK ALL FUNCTIONS & ENSURE NO AIR LEAK", "CHECK DOOR SUB CONVR RUNNING BY  0.5 MTR MOVING",
                     "CHECK NO FAULT IN GP AND PANEL", "CHECK FAULT ALRAM RELAY FIXED IN PANEL", "CHECK PC AND TOUCH FUNCTION  , SERVER PC STATUS", "0.5 METER MOVE IN AUTO MODE & ENSURE 'T' STOP AT STN NO 104 ONLY", "LIFTER MANUAL MODE  OPERTAION CHECK",
                     "ONE AUTO CYCLE CHECK", "DL01 LIFTER & CONVEYOR MANUAL MODE FUNCTION CHECK", "MIDDLE LIFTER FUNCTION CHECK IN MANUAL MODE", "TRAVERSER MANUAL MODE FUNCTION CHECK", "CHECK ALL FUNCTIONS  & ENSURE NO AIR LEAK",
                     "CHECK FUEL TANK TROLLEY & LIFTER  FWD/REV FUNCTION", "ENSURE CONVEYOR WORKING IN MANUAL MODE", "4 POST LIFTER & CONVEYOR MANUAL MODE FUNCTION CHECK", "2 POST LIFTER MANUAL MODE FUNCTION CHECK", "DECKING UP/DN  FUNCTION CHECK",
                     "DECKING FOR/REV FUNCTION CHECK", "DECKING POWER MOLLER FUNCTION CHECK", "BOTH LH WORK TROLLEY MANUAL FUNCTION CHECK", "DOWN LIFTER  MANUAL FUNCTION CHECK", "CHECK REMOTE PC & BOTY S1 & MODULE PLC PROGRAM  ONLINE",
                     "4 POST LIFTER & CONVEYOR MANUAL MODE FUNCTION CHECK", "2 POST LIFTER MANUAL MODE FUNCTION CHECK", "UNLOADING LIFTER MANUAL MODE FUNCTION CHECK", "DECKING UP/DN  FUNCTION CHECK", "DECKING FOR/REV FUNCTION CHECK",
                     "DECKING  POWER MOLLER FUNCTION CHECK", "BOTH LH WORK TROLLEY MANUAL FUNCTION CHECK", "CL04  DROP  LIFTER  MANUAL FUNCTION CHECK", "CHECK FA SEQUENCE IN ORDER  AND MATCHING WITH CURRENT BODY", "CHECK REMOTE PC & ALL SUB LINE PROGRAMS  ONLINE",
                     "CONVEYOR RUNNING CHECK BY AUTO START", "CL01 LIFTER MANUAL OPERATION CHECK", "CHECK FA SEQUENCE IN ORDER  AND MATCHING WITH CURRENT BODY", "CHECK NO FAULT IN  ENGINE SUB LINE PANEL ( EXCEPT WORK LINE C/V T STOP)", "CL02 DROP LIFTER MANUAL FUNCTION CHECK",
                     "CL03 DROP LIFTER AUTO FUNCTION CHECK", "CL05 TO CL06  DROP LIFTERS  MANUAL FUNCTION CHECK", "CHECK ENGINE TILTER UP/DOWN FUNCTION", "CHECK BELT TENSIONER FUNCTION", "CHECK FILLING GUN WORKING CONDITION",
                     "CHEK HOIST UP/DOWN  & FOR/REV MOVEMENTT CHECK", "CHECK AUTO START CONDITION IN PANEL AND ENSURE NO FAULT IN GP", "CHECK IF ANY AIR LEAK FROM TROLLEY", "CHECK PLC PROGRAM IN ONLINE", "ONE AUTO CYCLE CHECK",
                     "CHECK ALL FUNCTIONS  & ENSURE NO AIR LEAK", "CHECK  CONVEYOR RUNNING IN MANUAL MODE", "SIMULATE BRAKE GUN CYCLE AND ENSURE CLAMP /DECLAMP, VACCUM PUMP FUNCTION OK", "ENSURE MES SEQ MATCH WITH CAR BODY", "ENSURE CONSOLE FUNCTION IN MANUAL MODE",
                     "SIMULATE BRAKE GUN CYCLE AND ENSURE CLAMP /DECLAMP, VACCUM PUMP FUNCTION OK", "ENSURE CONSOLE FUNCTION IN MANUAL MODE", "SIMULATE RADIATOR  GUN CYCLE AND ENSURE CLAMP /DECLAMP, VACCUM PUMP FUNCTION OK", "ENSURE MES SEQ MATCH WITH CAR BODY", "SIMULATE RADIATOR  GUN CYCLE AND ENSURE CLAMP /DECLAMP, VACCUM PUMP FUNCTION OK",
                     "ENSURE MES SEQ MATCH WITH CAR BODY", "CHECK MES SEQUENCE & MATCH WITH CAR BODY", "CHECK GUN  FUNCTION IN MANUAL MODE", "ENSURE CONSOLE FUNCTION IN MANUAL MODE", "ENSURE A/C CHARGE BOOSTER POWER AND MASTER POWER ON",
                     "ENSURE MES SEQ MATCH WITH CAR BODY", "SIMULATE  FILLING CYCLE AND VACCUM PUMP FUNCTION OK", "ENSURE CONSOLE FUNCTION IN MANUAL MODE", "ENSURE MES SEQ MATCH WITH CAR BODY", "SIMULATE  FILLING CYCLE AND VACCUM PUMP FUNCTION OK",
                     "ENSURE CONSOLE FUNCTION IN MANUAL MODE", "CHECK ALL FUNCTIONS & ENSURE NO AIR LEAK", "CHECK TYRE MOUNT BUCKET  FUNCTION IN MANUAL MODE", "CHECK ONE AUTO CYCLE  &  ENSURE TVL LIFTER FUNCTION", "CHECK SPARE TYRE GP SEQUENCE BUFFER AND MATCHING",
                     "CHECK NUT RUNNERS  FUNCTION IN MANUAL MODE", "SIMULATE  PRIMER ROBOT ROUTING IN GLASS", "SIMULATE  SEALER  ROBOT ROUTING IN GLASS AFTER PASTING MASKING TAPE", "ENSURE SEALANT DISPENSING AND ALL PUMPS WORKING IN MANUAL MODE", "SIMULATE  PRIMER ROBOT ROUTING IN GLASS",
                     "SIMULATE  SEALER  ROBOT ROUTING IN GLASS AFTER PASTING MASKING TAPE", "ENSURE SEALANT DISPENSING AND ALL PUMPS WORKING IN MANUAL MODE", "CHECK ALL VISION SYSTEM APPLICATION RUNNING STATUS  AND MONITOR FUNCTION", "ENSURE NO FAULT  IN GP PANEL EXCEPT ROBOT  MODE DISABLE", "ENSURE NO AIR LEAK FORM DG SUB LINE",
                     "CHECK REMOTE PC & ALL SUB LINE PROGRAMS  ONLINE", "CHECK ALL FUNCTIONS & ENSURE NO AIR LEAK", "CHECK LABEL PRINTING SAMPLE", "CHECK LABEL PRINTING  SAMPLE", "ENSURE NO FAULT IN CONTROL PANEL",
                     "CHECK BOTH LH AND RH LIFTER FUNCTION IN MANUAL MODE", "ONE AUTO CYCLE CHECK", "CHECK RH SEAT TRANSFER UNIT IN MANUAL MODE & ENSURE NO AIR LEAK", "CHECK ALL FUNCTIONS & ENSURE NO AIR LEAK", "CHECK ALL FUNCTIONS & ENSURE NO AIR LEAK",
                     "ONE AUTO CYCLE CHECK", "CHECK PLC STATUS  AND ENSURE NO FAULT IN PANEL", "ONE AUTO CYCLE CHECK ( SIMULATE)", "CHECK CAR FULL PHOTO SENSOR  FUNCTION", "CHECK MANUAL OPERATION  OF  ALL DEVICES",
                     "CHECK MES DATA CONNECTION STATUS IN PC", "CHECK MANUAL OPERATION  OF  ALL DEVICES", "CHECK MES DATA CONNECTION STATUS IN PC", "CHECK MANUAL OPERATION  OF  ALL DEVICES", "CHECK MES DATA CONNECTION STATUS IN PC",
                     "CHECK  PC APPLICATION RUNNING STATUS & U ROBO STATUS", "CHECK  PC APPLICATION RUNNING STATUS & U ROBO STATUS", "CHECK  PC APPLICATION RUNNING STATUS & U ROBO STATUS","CHECK ALL RETAINING DEVICES FUNCTIONS ONE TIME", "IF NO VEHICLE IN M/C, CALIBRATE THE M/C",
                     "CHECK QNX PC AND FRONT PANEL PC STATUS & DRIVER MONITOR FUNCTION", "CHECK ALL RETAINING DEVICES FUNCTIONS ONE TIME", "IF NO VEHICLE IN M/C, CALIBRATE THE M/C", "CHECK QNX PC AND FRONT PANEL PC STATUS & DRIVER MONITOR FUNCTION", "CHECK ALL RETAINING DEVICES FUNCTIONS ONE TIME",
                     "IF NO VEHICLE IN M/C, CALIBRATE THE M/C", "CHECK QNX PC AND FRONT PANEL PC STATUS & DRIVER MONITOR FUNCTION", "CHECK  PIT WATER LEVEL IS OK","CHECK SHOWER PUMP & BLOWER WORKING", "CHECK NOZZLE DUCT  FUCNTION & INTERLOCK",
                     "CHECK  PIT WATER LEVEL IS OK", "CHECK SHOWER PUMP & BLOWER WORKING", "CHECK NOZZLE DUCT  FUCNTION & INTERLOCK", "CHECK CONVEYOR RUNNING", "CHECK CONVEYOR RUNNING",
                     "CHECK CONVEYOR RUNNING", "CHECK CONVEYOR RUNNING", "CHECK ALL BLOWERS AND PUMP WORKING", "AUTO START AND CONVEYOR RUNNING CHECK", "CHECK IF ANY AIR LEAK FROM STOARGE LINE",
                     "CHECK TYRE SEQUENCE BUFFER  ATY", "ENSURE NO FAULT IN CONTROL PANEL/ OP PANELS", "CHECK M/C POWER AND READY ON STATUS", "CHECK IF ANY AIR LEAK FROM M/C", "CHECK 5 TYRES MOUNTING COMPLETE CYCLE",
                     "CHECK SEQUENCE BUFFER QTY  & MATCHING", "CHECK IF ANY AIR LEAK FROM M/C", "CHECK M/C READY ON AND NO FAULT IN GP PANEL", "ENSURE MACHINE AUTO CONDITION AND NO FAULT IN GP", "CHECK EQUIPMENT POWER ON AND APPLICATION RUNNING STATUS",
                     "ENSURE POWER ON, PLC STATUS  & NO FAULT IN PANEL", "CHECK CONVEYOR RUNNING  IN MANUAL MODE", "CHECK 5 TYRES BALANCING CYCLE", "CHECK IF ANY ABNORMAL  AIR LEAK FROM M/C",  "CHECK MACHINE AUTO START STATUS AND NO FAULT IN GP PANEL",
                     "CHECK IF ANY ABNORMAL  AIR LEAK FROM M/C", "ENSURE POWER ON, PLC STATUS  & NO FAULT IN PANEL& OP PANEL","CHECKBELT CONVEYOR FUNCTION IN MANUAL MODE","ENSURE POWER ON, PLC STATUS  & NO FAULT IN PANEL& OP PANEL","CHECK CONVEYOR RUNNING CONDITION AND ANY ABNORMAL SOUND,"
             };

        }else{

             line = new String[]{
                     "MAIN", "TRIM", "ENGINE SUB", "CHASSIS", "CHASSIS",
                     "CHASSIS", "CHASSIS", "ENGINE SUB", "ENGINE SUB", "ENGINE SUB",
                     "ENGINE SUB", "ENGINE SUB", "TYRE SUB", "TYRE SUB", "TYRE SUB",
                     "FILLING", "FILLING", "FILLING", "FILLING", "FINAL",
                     "FINAL", "FINAL", "FINAL", "FINAL", "FINAL", "FINAL"
             };
             equipmentName = new String[]{
                     "MAIN CONVEYOR", "DOOR REMOVE LOADERS", "CRASH PAD LOADER", "DECKING CART", "DECKING CART",
                     "DECKING CART", "FS/RS CONVEYOR", "ENGINE HOIST", "ENGINE SUB FRAME LOADER", "TM LOADER",
                     "ENGINE LOADING AIR HOIST", "REAR AXLE LOADER", "TYRE MOUNTING M/C", "INFLATOR", "WHEEL BALANCING M/C",
                     "BRAKE OIL FILLING M/C", "RADIATOR FILLING M/C", "W/WASHER FILLING M/C", "A/C CHARGER", "OPEN/CLOSE DEVICE",
                     "A2 AIR BLEEDING M/C", "SEAT LOADERS", "DOOR ATTACH JIG", "A2  D/G M/C", "A2  D/G M/C", "FUEL FILLING M/C"
             };
             checkDetails = new String[]{
                     "MOVE CONVEYOR IN SYNCHRO AROUND 600 MM", "CHECK ALL FUNCTIONS & ENSURE NO AIR LEAK", "ENSURE NO AIR LEAK AND ITS PROPER WORKING", "ENGINE DECKING UP/DN  FUNCTION CHECK", "REAR DECKING UP/DN  FUNCTION CHECK",
                     "DECKING FOR/REV FUNCTION CHECK", "CHECK AUTOI START AND NO FAULT CONDITION", "CHECK HOIST UP/DOWN  & FOR/REV MOVEMENT CHECK", "ENSURE NO AIR LEAK AND ITS PROPER WORKING", "ENSURE NO AIR LEAK AND ITS PROPER WORKING",
                     "ENSURE NO AIR LEAK AND ITS PROPER WORKING", "ENSURE NO AIR LEAK AND ITS PROPER WORKING", "ENSURE NO AIR LEAK AND  TYRE TURN TABLE AND CLAMP /DECLAMP FUNCTION", "CHECK  AIR FILLING GUN FUNCTION  AND ENSURE NO AIR LEAK", "CHECK  BALANCING CYCLE  FUNCTION WITOUT TYRE",
                     "SIMULATE BRAKE GUN CYCLE AND ENSURE CLAMP /DECLAMP, VACCUM PUMP FUNCTION OK", "SIMULATE RADIATOR  GUN CYCLE AND ENSURE CLAMP /DECLAMP, VACCUM PUMP FUNCTION OK", "CHECK GUN  FUNCTION IN MANUAL MODE", "SIMULATE  FILLING  CYCLE AND VACCUM PUMP FUNCTION OK", "ENSURE  NO  INTERFERENCE AT HANGER OPEN/ DEVICE AREA",
                     "CHECK AIR BLEEEDING CYCLE FUNCTIONING BY CYCLE START", "ENSURE NO AIR LEAK FROM LOADER", "ENSURE NO AIR LEAK FROM LOADER", "SIMULATE  SEALER  ROBOT ROUTING IN GLASS AFTER PASTING MASKING TAPE", "ENSURE SEALANT DISPENSING AND ALL PUMPS WORKING IN MANUAL MODE", "CHECK M/C READY ON CONDITION, AND  ENSURE NO FAULT"
             };

        }

        ename = (TextView) findViewById(R.id.empName);
        empNo = (TextView) findViewById(R.id.empNumber);
        category = (TextView) findViewById(R.id.category);
        txtLine = (TextView) findViewById(R.id.line);
        txtEqipName = (TextView) findViewById(R.id.equip_name);
        txtCheckDetails = (TextView) findViewById(R.id.check_details);
        optionsGroup = (RadioGroup) findViewById(R.id.options);
        opA = (RadioButton) findViewById(R.id.optionA);
        opB = (RadioButton) findViewById(R.id.optionB);
        opC = (RadioButton) findViewById(R.id.optionC);
        prevButton = (Button) findViewById(R.id.prev);

        prevButton.setVisibility(View.GONE);
        Answers = new ArrayList<>();

        ename.setText("Emp Name : " + empName);
        empNo.setText("Emp No   : " + empNumber);
        category.setText("Shop  : " + shop);


        flag = -1;
        score = 0;
        ans = 0;
        nextC = 0;
        submit = true;
        goNext();
    }

    public void goNext() {
        flag++;
        if (flag >= equipmentName.length) {
            flag = equipmentName.length - 1;
        }

        txtLine.setText("Line : " + line[flag]);
        txtEqipName.setText("Equipment Name : " + equipmentName[flag]);
        txtCheckDetails.setText(checkDetails[flag]);

        try {
            if (Answers.get(flag) == 1) {
                opA.setChecked(true);
            } else if (Answers.get(flag) == 2) {
                opB.setChecked(true);
            } else if (Answers.get(flag) == 3) {
                opC.setChecked(true);
            } else {
                optionsGroup.clearCheck();
            }
        } catch (Exception e) {
            optionsGroup.clearCheck();
        }
    }

    public void clickPrev(View view) {
        Log.e("Count", String.valueOf(flag));

        int selectedId = optionsGroup.getCheckedRadioButtonId();
        switch (selectedId) {
            case R.id.optionA:
                ans = 1;
                break;
            case R.id.optionB:
                ans = 2;
                break;
            case R.id.optionC:
                ans = 3;
                break;
            default:
                ans = 0;
        }

        if (flag >= 0) {
            try {
                Answers.set(flag, ans);
            } catch (Exception e) {
                Answers.add(flag, ans);
            }
        }


        if (flag < equipmentName.length - 1) {
            goPrev();
        } else if (flag == equipmentName.length - 1) {
            Button button = findViewById(R.id.next);
            button.setVisibility(View.VISIBLE);
            button = findViewById(R.id.submit);
            button.setVisibility(View.INVISIBLE);
            optionsGroup.clearCheck();
            goPrev();
        }
        if (flag == 0)
            prevButton.setVisibility(View.GONE);
        nextC--;
        ans = 0;
    }

    public void goPrev() {
        flag--;

        txtLine.setText("Line : " + line[flag]);
        txtEqipName.setText("Equipment Name : " + equipmentName[flag]);
        txtCheckDetails.setText(checkDetails[flag]);

        try {
            if (Answers.get(flag) == 1) {
                opA.setChecked(true);
            } else if (Answers.get(flag) == 2) {
                opB.setChecked(true);
            } else if (Answers.get(flag) == 3) {
                opC.setChecked(true);
            } else {
                optionsGroup.clearCheck();
            }
        } catch (Exception e) {
            optionsGroup.clearCheck();

        }
    }


    public void clickNext(View view) {

        int selectedId = optionsGroup.getCheckedRadioButtonId();
        if (selectedId == -1) {
            Toast.makeText(MainActivity.this, "Please Select any options...", Toast.LENGTH_SHORT).show();
            return;
        }
        switch (selectedId) {
            case R.id.optionA:
                ans = 1;
                break;
            case R.id.optionB:
                ans = 2;
                break;
            case R.id.optionC:
                ans = 3;
                break;
            default:
                ans = 0;
        }

        if (flag >= 0) {
            try {
                Answers.set(flag, ans);
            } catch (Exception e) {
                Answers.add(flag, ans);
            }
        }


        if (flag < equipmentName.length - 2) {
            optionsGroup.clearCheck();
            goNext();
        } else if (flag == equipmentName.length - 2) {
            Button button = findViewById(R.id.next);
            button.setVisibility(View.INVISIBLE);
            button = findViewById(R.id.submit);
            button.setVisibility(View.VISIBLE);
            optionsGroup.clearCheck();
            goNext();
        }
        if (flag > 0)
            prevButton.setVisibility(View.VISIBLE);
        nextC++;
        ans = 0;
        Log.e("Count", String.valueOf(flag));
    }


    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Really Exit?")
                .setMessage("Are you sure you want to exit?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        MainActivity.super.onBackPressed();
                        //MainActivity.this.finish();
                    }
                }).create().show();
    }


    public void clickSubmit(View view) {
        clickNext(view);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss-a");
        String data_time = simpleDateFormat.format(new Date());
        saveExcelFile(this,"Assembly_Rcc_"+data_time+".xls");
    }

    private boolean saveExcelFile(Context context, String fileName) {

        boolean success = false;

        //Date and Time
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss a");
        String data_time = simpleDateFormat.format(new Date());

        //New Workbook
        Workbook wb = new HSSFWorkbook();
        Cell cell = null;

        //Cell style for header row
        CellStyle cs = wb.createCellStyle();
        cs.setFillForegroundColor(HSSFColor.YELLOW.index);
        cs.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cs.setAlignment(CellStyle.ALIGN_CENTER);
        cs.setWrapText(true);
        Font fontTitle = wb.createFont();
        //fontTitle.setFontHeightInPoints((short) 14);
        fontTitle.setBoldweight(Font.BOLDWEIGHT_BOLD);
        //fontTitle.setFontName(HSSFFont.FONT_ARIAL);
        cs.setFont(fontTitle);
        cs.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
        cs.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
        cs.setBorderRight(HSSFCellStyle.BORDER_MEDIUM);
        cs.setBorderLeft(HSSFCellStyle.BORDER_MEDIUM);

        //Cell No Style
        CellStyle ns = wb.createCellStyle();
        ns.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
        ns.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
        ns.setBorderRight(HSSFCellStyle.BORDER_MEDIUM);
        ns.setBorderLeft(HSSFCellStyle.BORDER_MEDIUM);
        ns.setAlignment(CellStyle.ALIGN_CENTER);
        ns.setWrapText(true);
        //fontTitle.setFontHeightInPoints((short) 14);
        //fontTitle.setFontName(HSSFFont.FONT_ARIAL);
        Font fontTitle1 = wb.createFont();
        ns.setFont(fontTitle1);
        //ns.setFillForegroundColor(HSSFColor.YELLOW.index);
        //ns.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

        //New Sheet
        Sheet sheet = null;
        sheet = wb.createSheet("ASSEMBLY RCC");

        // Generate column headings
        Row row1 = sheet.createRow(0);
        Row row2 = sheet.createRow(1);
        Row row3 = sheet.createRow(2);
        Row row4 = sheet.createRow(4);
        Row row5 = sheet.createRow(5);

        //FIRST ROW

        cell = row1.createCell(0);
        cell.setCellValue("");
        cell.setCellStyle(ns);

        cell = row1.createCell(1);
        cell.setCellValue("");
        cell.setCellStyle(ns);

        cell = row1.createCell(2);
        cell.setCellValue("");
        cell.setCellStyle(ns);

        cell = row1.createCell(3);
        cell.setCellValue("CHECKED BY");
        cell.setCellStyle(cs);


        cell = row1.createCell(4);
        cell.setCellValue("NAME");
        cell.setCellStyle(cs);

        cell = row1.createCell(5);
        cell.setCellValue("SIGNATURE");
        cell.setCellStyle(cs);

        //Second Row

        cell = row2.createCell(0);
        cell.setCellValue("");
        cell.setCellStyle(ns);

        cell = row2.createCell(1);
        cell.setCellValue("EMP NAME");
        cell.setCellStyle(ns);

        cell = row2.createCell(2);
        cell.setCellValue(empName);
        cell.setCellStyle(ns);

        cell = row2.createCell(3);
        cell.setCellValue("VERIFIED BY  ( CELL LEADER)");
        cell.setCellStyle(cs);


        cell = row2.createCell(4);
        cell.setCellValue("");
        cell.setCellStyle(ns);

        cell = row2.createCell(5);
        cell.setCellValue("");
        cell.setCellStyle(ns);

        //Third Row
        cell = row3.createCell(0);
        cell.setCellValue("");
        cell.setCellStyle(ns);

        cell = row3.createCell(1);
        cell.setCellValue("EMP NO");
        cell.setCellStyle(ns);

        cell = row3.createCell(2);
        cell.setCellValue(empNumber);
        cell.setCellStyle(ns);

        cell = row3.createCell(3);
        cell.setCellValue("APPROVED BY ( SECTION LEADER)");
        cell.setCellStyle(cs);


        cell = row3.createCell(4);
        cell.setCellValue("");
        cell.setCellStyle(ns);

        cell = row3.createCell(5);
        cell.setCellValue("");
        cell.setCellStyle(ns);


        //Forth Row

        cell = row4.createCell(0);
        cell.setCellValue("");
        cell.setCellStyle(ns);

        cell = row4.createCell(1);
        cell.setCellValue("Shop");
        cell.setCellStyle(ns);

        cell = row4.createCell(2);
        cell.setCellValue(shop);
        cell.setCellStyle(ns);

        cell = row4.createCell(3);
        cell.setCellValue("ASSEMBLY SHOP EQUIPMENT READY CONDITION CHECK");
        cell.setCellStyle(cs);

        cell = row4.createCell(4);
        cell.setCellValue("DATE : ");
        cell.setCellStyle(ns);

        cell = row4.createCell(5);
        cell.setCellValue(data_time);
        cell.setCellStyle(ns);

        //Fifth Row
        cell = row5.createCell(0);
        cell.setCellValue("SL NO");
        cell.setCellStyle(cs);

        cell = row5.createCell(1);
        cell.setCellValue("LINE");
        cell.setCellStyle(cs);

        cell = row5.createCell(2);
        cell.setCellValue("EQUIPMENT NAME");
        cell.setCellStyle(cs);

        cell = row5.createCell(3);
        cell.setCellValue("CHECK DETAIL");
        cell.setCellStyle(cs);

        cell = row5.createCell(4);
        cell.setCellValue("CHECK STATUS");
        cell.setCellStyle(cs);

        cell = row5.createCell(5);
        cell.setCellValue("Remark");
        cell.setCellStyle(cs);

        for (int i=0;i<equipmentName.length;i++){
            Row row = sheet.createRow(i+6);

            String status = "";
            if(Answers.get(i) == 1){
                status = "Yes";
            }else if(Answers.get(i) == 2){
                status = "No";
            }else if(Answers.get(i) == 3){
                status = "Pending";
            }else{
                status = "";
            }


            cell = row.createCell(0);
            cell.setCellValue(i+1);
            cell.setCellStyle(ns);

            cell = row.createCell(1);
            cell.setCellValue(line[i]);
            cell.setCellStyle(ns);

            cell = row.createCell(2);
            cell.setCellValue(equipmentName[i]);
            cell.setCellStyle(ns);

            cell = row.createCell(3);
            cell.setCellValue(checkDetails[i]);
            cell.setCellStyle(ns);

            cell = row.createCell(4);
            cell.setCellValue(status);
            cell.setCellStyle(ns);

            cell = row.createCell(5);
            cell.setCellValue("");
            cell.setCellStyle(ns);
            Log.e("index", String.valueOf(i));
        }


        sheet.setColumnWidth(0, (15 * 100));
        sheet.setColumnWidth(1, (15 * 200));
        sheet.setColumnWidth(2, (15 * 350));
        sheet.setColumnWidth(3, (15 * 800));
        sheet.setColumnWidth(4, (15 * 350));
        sheet.setColumnWidth(5, (15 * 350));
        //row1.setHeightInPoints((2*sheet.getDefaultRowHeightInPoints()));

// Create a path where we will place our List of objects on external storage
        File file = new File(context.getExternalFilesDir(null), fileName);
        FileOutputStream os = null;
        try {
            os = new FileOutputStream(file);
            wb.write(os);
            Log.w("FileUtils", "Writing file" + file);
            success = true;

        } catch (IOException e) {
            Log.w("FileUtils", "Error writing " + file, e);
        } catch (Exception e) {
            Log.w("FileUtils", "Failed to save file", e);
        } finally {
            try {
                if (null != os)
                    os.close();
            } catch (Exception ex) {
            }
        }

        openXLS(fileName);

        return success;
    }


    private void openXLS(String fileName) {

        File file = new File(this.getExternalFilesDir(null), fileName);
        Uri uri ;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            uri = FileProvider.getUriForFile(getApplicationContext(), this.getPackageName() + ".provider", file);
        } else {
            uri = Uri.fromFile(file);
        }

        Intent intent = new Intent(Intent.ACTION_SEND);

        intent.setAction(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_TEXT, "Hello,");
        intent.putExtra(Intent.EXTRA_SUBJECT, "ASSEMBLY RCC");
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_STREAM,uri);
        intent.setType("application/vnd.ms-excel");
        intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(intent);

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Application not found", Toast.LENGTH_SHORT).show();
        }
    }

    public static boolean isExternalStorageReadOnly() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState)) {
            return true;
        }
        return false;
    }

    public static boolean isExternalStorageAvailable() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(extStorageState)) {
            return true;
        }
        return false;
    }
}